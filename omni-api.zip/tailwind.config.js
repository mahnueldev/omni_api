/** @type {import('tailwindcss').Config} */

// tailwind.config.js
module.exports = {
    content: ["./public/views/**/*.hbs", "./src/**/*.js"],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  