
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('Users', [
      {
       
        firstName: 'John',
        lastName: 'John',
        email: 'johndoe@example.com',
        password: '8345HFD34',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
       
        firstName: 'Elle',
        lastName: 'Elle',
        email: 'tellery@example.com',
        password: '5838598Y',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        
        firstName: 'Emmanuel',
        lastName: 'Emmanuel',
        email: 'emmyson@example.com',
        password: 'JSF87TW',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('Users', null, {});
  },
};
