## Omni API
### Features
- Well defined web and api routes
- Register
- Login functionality
- Logout functionality
- Email registeration confirmation 